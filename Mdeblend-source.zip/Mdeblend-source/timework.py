import numpy as np
import sys
import matplotlib.pyplot as plt

def timewrk(sitfile,mode,out,inp_n1,out_n1,t0):


    f=open(sitfile,'r')

    ntimeshots = 10000
    xin=["                "]*ntimeshots
    ntraces = 0
    maxline= -999999999999
    minline=  999999999999
    maxshot= -999999999999
    minshot=  999999999999

    for ix in range(ntimeshots):
        c = f.readline()
        if (c == '') :
            break
        xin[ix] = c
        lline = xin[ix].split()
        lineindxin = int(lline[1])
        shotindxin = int(lline[2])

        if ( lineindxin > maxline ):
            maxline = lineindxin
        if ( lineindxin < minline ):
            minline = lineindxin
    
        if ( shotindxin > maxshot ):
            maxshot = shotindxin
        if ( shotindxin < minshot ):
            minshot = shotindxin

        ntraces = ntraces + 1

        if (ntraces >= ntimeshots):
            sys.stderr.write('**** error - input times buffer is too small ***\n')  
            sys.stderr.write('**** error - input times buffer is too small ***\n')  
            sys.stderr.write('**** error - input times buffer is too small ***\n')  
            sys.stderr.write('**** error - input times buffer is too small ***\n')  
            raise Exception('****error - input times buffer is too small ***\n')

    nshots = maxshot - minshot + 1
    nlines = maxline - minline + 1
    sys.stderr.write(' number of traces to generate='+str(ntraces)+'\n')  
    sys.stderr.write(' nlines ='+str(nlines)+'\n')  
    sys.stderr.write(' nshots ='+str(nshots)+'\n')  

    shottimes = np.zeros([ntraces],dtype=np.int64)
    shottimes_org = np.zeros([ntraces],dtype=np.int64)
    lineindx = np.zeros(ntraces, dtype=np.int32)
    shotindx = np.zeros(ntraces, dtype=np.int32)

    maxtime = -99999999999999999999999
    mintime = 99999999999999999999999
    for ix in range(ntraces):
        x=xin[ix]
        #sys.stderr.write(' x='+x+' ix='+str(ix)+'\n')  
        lline = x.split()
        #sys.stderr.write(' lline[0]='+lline[0]+'\n')  
    
        shottimes[ix] = int(lline[0])
        shottimes_org[ix] = int(lline[0])
        if (shottimes[ix] > maxtime):
            maxtime = shottimes[ix]
        if (shottimes[ix] < mintime):
            mintime = shottimes[ix]
    
    if ( mode == 'blend'):
        t0 = mintime
        sys.stderr.write(' ---t0='+str(t0)+'\n')
        out.put('t0',t0)
    
    if ( mode == 'deblend'):
            lendata =  out_n1 + maxtime-mintime+1

    # make time origin 0
    for ix in range(ntraces):
        x=xin[ix]
        lline = x.split()
    
        shottimes[ix] = shottimes[ix] - t0
    
        lineindx[ix] = int(lline[1])-minline
        shotindx[ix] = int(lline[2])-minshot

    #sys.stderr.write(' ---deblend shottimes='+str(shottimes)+'\n')
    itimeerror = 0
    if (mode == 'deblend'):
        for ix in range(ntraces):
            if (shottimes[ix]+out_n1 > inp_n1 or shottimes[ix] < 0):
                 sys.stderr.write(' +++ time error in output shot '+str(ix)+"\n")
                 sys.stderr.write(' +++ time error, lendata='+str(lendata)+"\n")
                 sys.stderr.write(' +++ input trace length = '+str(inp_n1)+"\n")
                 sys.stderr.write(' +++ shottime = '+str(shottimes[ix])+"\n")
                 sys.stderr.write(' +++ original shottime = '+str(shottimes_org[ix])+"\n")
                 sys.stderr.write(' +++ output trace length = '+str(out_n1)+"\n")
                 itimeerror = 1

    if (itimeerror != 0):
        sys.stderr.write(" +++ exiting +++ \n")
        sys.exit(1)

    f.close()

    return (shottimes,nlines,nshots,lineindx,shotindx,maxtime,mintime,ntraces)


