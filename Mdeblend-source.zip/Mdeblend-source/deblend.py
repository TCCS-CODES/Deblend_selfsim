import numpy as np
import time
import math
import matplotlib
#matplotlib.use("Qt4Agg") # set the backend
import matplotlib.pyplot as plt
from pylab import *
import scipy.ndimage.filters as filt
from matplotlib import rc
import sys



#-----------------------------------------------------------------
#-----------------------------------------------------------------

# File: deblend.py. Separation quality diagnostic

""" Module deblend: This routine sets up a simple synthetic receiver gather 
and creates the corresponding continuous data.  It then deblends the 
continuous data to obtain the deblended data.

"""
def deblend(sdata,n1,dt,randtimes,niter,lendata,w1,w2,w3,nshots,nlines,lineindx,shotindx,ntraces):
    """ 
    Separate the overlapping sources.  
    niter is the number of iterations to use to solve the separation.
    """

    sys.stderr.write('w1 ='+str(w1)+'  w2='+str(w2)+' w3='+str(w3)+'\n')
    sys.stderr.write('n1 ='+str(n1)+'\n')

    sys.stderr.write(' number of iterations ='+str(niter)+'\n')

    n2 = nshots
    n3 = nlines

    n1pad = n1 
    if (n1 == 1): n1pad = 1
    n2pad = n2 
    if (n2 == 1): n2pad = 1
    n3pad = n3 
    if (n3 == 1): n3pad = 1

    if (w3 == 1): n3pad = n3  ## assume a 2D problem fir w3 == 1

    if (w1 > n1pad): w1 = n1pad
    if (w2 > n2pad): w2 = n2pad
    if (w3 > n3pad): w3 = n3pad

    a1 = 0
    a2 = 0
    a3 = 0


#  1.5 to have half again as many windows, i.e., 25% overlap
#  2.0 to have twice as many windows, i.e., 50% overlap
    k1 = int(2.0 * n1pad/(w1-a1+1.))
    if (k1 < 1): k1 = 1
    k2 = int(2.0 * n2pad/(w2-a2+1.))
    if (k2 < 1): k2 = 1
    k3 = int(2.0 * n3pad/(w3-a3+1.))
    if (k3 < 1): k3 = 1
    sys.stderr.write('k1 ='+str(k1)+'  k2='+str(k2)+' k3='+str(k3)+'\n')


#===== calculate the maximimum blending factor ====
    onearray = np.ones([n3, n2, n1])
    one_sdata=gammaf(onearray, randtimes,lendata, n1, lineindx,shotindx,ntraces)

    maxblendfact = max(one_sdata)
    sys.stderr.write(' maximum blend factor ='+str(maxblendfact)+'\n')


    if (niter == 0 ):
        combed = gammat(sdata, randtimes, n1, n1pad,
                    n2pad, n3pad,lineindx,shotindx,ntraces)
        return combed

#=================================================================
#     solve for the separated sources
#=================================================================

    mcalc = sparseinverse(sdata, n1pad, n2pad, n3pad,
                         n1, n2, n3,
                         niter, maxblendfact, randtimes,ntraces,
                         lendata,
                         lineindx,shotindx,
                         a1, a2, a3, w1, w2, w3, k1, k2, k3)

#=================================================================

    #newm = np.zeros([n3, n2, n1])
    newm = mcalc[0:n3,0:n2,0:n1]

    return newm

#==========================================================================

""" The subroutine gammat corresponds to the transpose of gamma 
referenced in the text.  One action of gammat is to take the continuous 
data and create the combed data, that is, the pseudo-deblended data.
"""


def gammat(sdata, randtimes, n1, n1pad, n2pad, n3pad,lineindx,shotindx,ntraces):
    """ 
    Transpose gamma, make combed data from the continuos. 

    sdata is the continuous data,
    randtimes is the array of random source times in samples,
    n1 is the length of the source traces to be generated,
    n1pad is the trace length padded for the fft,
    n2pad is the number of traces in the x-direction of
    the receiver gather padded for the fft,
    n3pad is the number of traces in the y-direction of
    the receiver gather padded for the fft,    
    """

    mcalc = np.zeros([n3pad, n2pad, n1pad])

    for ix in range(ntraces):
        iyi = lineindx[ix]
        ixi = shotindx[ix]
        ipoint = int(randtimes[ix])
        mcalc[iyi, ixi, 0:n1] = sdata[ipoint:ipoint+n1]

    return mcalc


#==========================================================================

"""
The subroutine gammaf is the forward action of gamma referenced in the text.
One action of gammaf is to build the continuous data from the non-simultaneous
source data.  
"""


def gammaf(inarray, randtimes,lendata, n1, lineindx,shotindx,ntraces):
    """ 
    Forward gamma, make continuous data from the unblended model data. 
     inarray is the input buffer for the separated sources. 
     randtimes is the array of random source times in samples,
     n1 is the length of the source traces to be generated,

    The output, sdata, is the continuos record generated from the input receiver 
    gather.
    """

    
    sdata = np.zeros(int(lendata))

    for ix in range(ntraces):
        ixi = shotindx[ix]
        iyi = lineindx[ix]
        ipoint = int(randtimes[ix])
        sdata[ipoint:ipoint+n1] =\
            sdata[ipoint:ipoint+n1] +\
            inarray[iyi, ixi, 0:n1]

    return sdata

#==========================================================================

"""
This sparse inversion subroutine solves for 
the separated seismic data, that is, the deblended data.  
"""


def sparseinverse(sdata, n1pad, n2pad, n3pad,
                  n1, n2, n3,
                  niter, maxblendfact, randtimes,ntraces,
                  lendata,
                  lineindx,shotindx,
                  a1, a2, a3, w1, w2, w3, k1, k2, k3):
    """ 
    sdata is the input continuous data,
    n1pad is the trace length padded for the fft,
    n2pad is the number of traces in the x-direction of 
    the receiver gather padded for the fft,
    n3pad is the number of traces in the y-direction of 
    the receiver gather padded for the fft,
    n1 is is the length of the source traces extraced from 
    the continuous data,
    n2 is the number of traces in the x-direction of the receiver gather,
    n3 is the number of traces in the y-direction of the receiver gather.
    niter is the number of iterations to use in the solver,
    maxblendfact is the maximum blending factor, used for stability,
    randtimes is the array of random source times in samples.

    The output mcalc the output receiver gather.

    """
#==========================================================================

    twopi = 2.0 * math.pi

    dt = 0.002
    dxtrc = 48.0
    dytrc = 100.0


    trange = dt * n1pad
    xrange = dxtrc * n2pad
    yrange = dytrc * n3pad

    dw = twopi /trange
    dkx = twopi /xrange
    dky = twopi /yrange
    nt2 = round(n1pad/2)



#==========================================================================

    mcalc = np.zeros([n3pad, n2pad, n1pad])

    combed = gammat(sdata, randtimes, n1, n1pad,
                    n2pad, n3pad,lineindx,shotindx,ntraces)

#==========================================================================
    #fcombed = np.fft.fft2(combed)
    #fcombed = fcombed * maskfreq
    #combed = np.real( np.fft.ifft2(fcombed) )
#==========================================================================

    maxcoef, bigmax = getmax(a1, a2, a3, k1, k2, k3,
                     combed, n1, n2, n3, w1, w2, w3,
                     n1pad,n2pad,n3pad )

#####---------------------------------------------------
# -- set to one common threshold as in the old code --
##    maxcoef[:,:] = bigmax
#####---------------------------------------------------
    lengthdata = np.shape(sdata)[0]
    dp = np.zeros(int(lengthdata))

## printout interval
    nskip = 100
    if (niter <= 400): nskip = 20
    if (niter <= 100):
        nskip = 10
    if (niter < 20):
        nskip = 1
    if (niter > 3000):
        nskip = 500

#-- padding only for fft ---
    w1pad = int(w1 * 1.5)
    if (w1 == 1):
        w1pad = 1
    w2pad = int(w2 * 1.5)
    if (w2 == 1):
        w2pad = 1
    w3pad = int(w3 * 1.5)
    if (w3 == 1):
        w3pad = 1

    ftrac_sv = np.zeros((w3pad,w2pad,w1pad,k1,k2,k3))

    for iter in range(1, niter+1):
        if (iter%nskip == 0):
            sys.stderr.write(' ---- iter='+str(iter)+' \n')
        dnew = sdata - dp
        dx = gammat(dnew, randtimes, n1, n1pad,
                    n2pad, n3pad,lineindx,shotindx,ntraces)

        mshotsv = np.copy(mcalc)
        mcalc = mcalc + dx

#-----------------------------------------------------------
        mcalc = dddwindow(a1, a2, a3, k1, k2, k3,
                         mcalc,  w1, w2, w3,
                         maxcoef, niter, iter,
                         n1pad,n2pad,n3pad,
                         w1pad,w2pad,w3pad,
                         ftrac_sv,
                         dt,dxtrc )
#-----------------------------------------------------------

        temp = mcalc - mshotsv
        mcalc = mshotsv + temp * 0.72 / maxblendfact  # stabilize
        #mcalc = mshotsv + temp * 0.1 / maxblendfact  # stabilize

        dp = gammaf(mcalc, randtimes,lengthdata, n1, lineindx,shotindx,ntraces)  # calculated data

    return mcalc

#==========================================================================
"""
   dddwindow breaks the data up into windows, applies an fft, and thresholds
   the data according to the iteration.
"""

def dddwindow(a1, a2, a3, k1, k2, k3,
              wall,  w1, w2, w3,
              maxcoef, niter, iter,
              n1pad,n2pad,n3pad ,
              w1pad,w2pad,w3pad,
              ftrac_sv,
              dt,dxtrc):

    big = np.amax( np.abs( wall ))
    if (big == 0.0): 
        big= 1.0

    resi = np.zeros((n3pad, n2pad, n1pad))
    windwt = fxtent3(a1, a2, a3, w1, w2, w3, big)
    wallwt=mkfxwallwt3(k1, k2, k3, windwt, w1, w2, w3, n1pad, n2pad, n3pad)

    #complexplot(wall[:,:,0:100],' wall ')

# loop over windows -------
    for j3 in range(k3):
        for j2 in range(k2):
            for j1 in range(k1):

                pmodl = patch3fwd(j1, j2, j3, k1, k2, k3, wall,
                                  n1pad, n2pad, n3pad,  w1, w2, w3)

                #if (iter == 1):
                    #for i3 in range(w3):
                        #for i2 in range(w2):
                            #ampw = np.amax(np.abs( pmodl[i3,i2,:] ) )
                            #maskorig[i3,i2] = 0.0
                            #if (ampw > 0.0):
                                #maskorig[i3,i2] = 1.0

##
# add in-window process here
##
                if (np.amax(np.abs(pmodl)) > 0.0):


                    pmodlpad = np.zeros((w3pad, w2pad, w1pad))
                    pmodlpad[0:w3,0:w2,0:w1] = pmodl

                    fpmodl = np.fft.fft2(pmodlpad)

                    #if (iter > 1):
                        #fpmodlxx = fpmodl * ftrac_sv[:,:,:,j1,j2,j3]
                    #else:
                        #fpmodlxx = fpmodl

                    fpmodlxx = fpmodl

                    tolmask = np.real(np.ones_like(fpmodlxx))

                    for if1 in range(int(w1pad)): ## do all the freqs

                        fpmodlf = fpmodlxx[:,:,if1]
                        ftolmask = np.real(np.ones_like(fpmodlf))

                        tolerance=maxcoef[j3,if1]*((float(niter)-iter)/niter)**2

                        ftolmask = ftolmask * \
                            np.greater(np.absolute(fpmodlf), tolerance)

                        tolmask[:,:,if1] = ftolmask

                    fpmodl = fpmodl * tolmask

 

                    pmodlpad = np.real(np.fft.ifft2(fpmodl))
                    pmodl = pmodlpad[0:w3,0:w2,0:w1] 


                    pmodl = windwt * pmodl

                    resi = patchconj(j1, j2, j3, k1, k2, k3,
                                 n1pad, n2pad, n3pad, pmodl,
                             w1, w2, w3, resi)

    resi = resi * wallwt
    #complexplot(resi[:,:,0:100],' resi ')
    #plt.show()

      
    return resi
#-----------------------------------------------------------
#-----------------------------------------------------------
#-----------------------------------------------------------

def fxtent3(a1, a2, a3, w1, w2, w3, big):

    """
   fxtent3 makes the weights for the small windows
    """

    windwt = np.zeros((w3, w2, w1))

    small = 0.00001 * big
    for i3 in range(w3):
        for i2 in range(w2):
            for i1 in range(w1):
                windwt[i3, i2, i1] = small

    s1 = int(a1)  # a1,a2,a3 are zero 
    e1 = int(w1)
    mid1 = (e1-1)/2.0
    wide1 = (e1-2*s1+1.)/2.0

    s2 = int(a2)
    e2 = int(w2)
    mid2 = (e2-1)/2.0
    wide2 = (e2-2*s2+1.)/2.0

    s3 = int(a3)
    e3 = int(w3)
    mid3 = (e3-1)/2.0
    wide3 = (e3-2*s3+1.)/2.0

    pi_over_2 = math.pi/2.0
    for i3 in range(s3, e3):
        y = cos(abs((i3-mid3)/wide3)*pi_over_2)
        for i2 in range(s2, e2):
            x = cos(abs((i2-mid2)/wide2)*pi_over_2)
            for i1 in range(s1, e1):
                z = cos(abs((i1-mid1)/wide1)*pi_over_2)

                windwt[i3, i2, i1] = windwt[i3, i2, i1] +\
                    max([small, x]) *\
                    max([small, y]) *\
                    max([small, z])


    return windwt


# wallwt = mkfxwallwt3(k1,k2,k3, wind, w1,w2,w3, n1,n2,n3)

def mkfxwallwt3(k1, k2, k3, wind, w1, w2, w3, n1pad, n2pad, n3pad):
    """
       mkfxwallwt3 makes the weights for the wall

    """

    wallwt = np.zeros((n3pad, n2pad, n1pad))
    for i3 in range(k3):
        for i2 in range(k2):
            for i1 in range(k1):
                wallwt = patchconj(i1, i2, i3, k1, k2, k3,
                                   n1pad, n2pad, n3pad, wind,
                                   w1, w2, w3, wallwt)
    for i3 in range(n3pad):
        for i2 in range(n2pad):
            for i1 in range(n1pad):
                if wallwt[i3, i2, i1] != 0.0:
                    wallwt[i3, i2, i1] = 1.0 / wallwt[i3, i2, i1]

    return wallwt


def patchconj(j1, j2, j3, k1, k2, k3,
              n1pad, n2pad, n3pad, wind,
              w1, w2, w3, wall):
    """
      patchconj merges the windows into the wall

    """

    if k3 != 1:
        s3 = int(0.5 + (n3pad - w3) * (j3)/(k3-1.))
    else:
        s3 = 0

    if k2 != 1:
        s2 = int(0.5 + (n2pad - w2) * (j2)/(k2-1.))
    else:
        s2 = 0

    if k1 != 1:
        s1 = int(0.5 + (n1pad - w1) * (j1)/(k1-1.))
    else:
        s1 = 0

    for i3 in range(w3):
        d3 = i3 + s3
        for i2 in range(w2):
            d2 = i2 + s2
            for i1 in range(w1):
                d1 = i1 + s1

                wall[d3, d2, d1] = wall[d3, d2, d1] + wind[i3, i2, i1]

    return wall

# wind = patch3fwd(j1,j2,j3, k1,k2,k3, wall,\
#                                 n1,n2,n3,  w1,w2,w3)


def patch3fwd(j1, j2, j3, k1, k2, k3, wall, n1pad, n2pad, n3pad,  w1, w2, w3):
    """
  patch3fwd extracts the windows from the wall

    """

    wind = np.zeros((w3, w2, w1))
    if k3 != 1:
        s3 = int(0.5 + (n3pad - w3) * (j3)/(k3-1.))
    else:
        s3 = 0

    if k2 != 1:
        s2 = int(0.5 + (n2pad - w2) * (j2)/(k2-1.))
    else:
        s2 = 0

    if k1 != 1:
        s1 = int(0.5 + (n1pad - w1) * (j1)/(k1-1.))
    else:
        s1 = 0

    for i3 in range(w3):
        d3 = i3 + s3
        for i2 in range(w2):
            d2 = i2 + s2
            for i1 in range(w1):
                d1 = i1 + s1
                wind[i3, i2, i1] = wind[i3, i2, i1] + wall[d3, d2, d1]

    return wind


def getmax(a1, a2, a3, k1, k2, k3,
           wall, n1, n2, n3, w1, w2, w3,
           n1pad,n2pad,n3pad ):
    """
  getmax gets the maxima of each frequency slice for thresholding

    """

    w1pad = w1 * 2
    if (w1 == 1):
        w1pad = 1
    w2pad = w2 * 2
    if (w2 == 1):
        w2pad = 1
    w3pad = w3 * 2
    if (w3 == 1):
        w3pad = 1



    maxcoef = np.zeros((n3,w1pad))

    for i3 in range(k3):
        for i2 in range(k2):
            for i1 in range(k1):

                pmodl_in = patch3fwd(i1, i2, i3, k1, k2, k3, wall,
                                  n1pad, n2pad, n3pad,  w1, w2, w3)
                pmodlpad = np.zeros((w3pad, w2pad, w1pad))
                pmodlpad[0:w3,0:w2,0:w1] = pmodl_in

                fpmodl = np.fft.fft2(pmodlpad)

                for ii1 in range(w1pad):
                    fmax = np.amax(np.abs(fpmodl[:,:,ii1]))
                    if (maxcoef[i3,ii1] < fmax):
                        maxcoef[i3,ii1] = fmax

        #if (1 == 2):
            #fig = plt.figure()
            #plt.plot(maxcoef[i3,:])
            #ttt = 'Maximum coeficients '+str(i3)
            #plt.title(ttt)
            #plt.show()

    bigmax = np.amax( maxcoef )

    return maxcoef, bigmax


def complexplot(xxxxx, ttt):
    """
  complexplot plots a 3D dataset - this is for QC purposes

    """
    ir = np.shape(xxxxx)[0]
    jr = np.shape(xxxxx)[1]
    kr = np.shape(xxxxx)[2]
    fig = plt.figure()
    mmm = np.abs(np.reshape(xxxxx, (ir*jr, kr)))
    plt.imshow(np.transpose(mmm), aspect='auto', cmap='jet')
    plt.title(ttt)
    plt.colorbar()
    #plt.show()
    #plt.show(block=True)


def complexplot2D(xxxxx, ttt):
    """
  complexplot plots a 2D dataset - this is for QC purposes

    """
    ir = np.shape(xxxxx)[0]
    jr = np.shape(xxxxx)[1]
    fig = plt.figure()
    #mmm = np.abs(np.reshape(xxxxx, (ir, jr)))
    plt.imshow(np.transpose(np.abs(xxxxx)), aspect='auto', cmap='jet')
    plt.title(ttt)
    plt.colorbar()


#=================================================================
#=================================================================
#=================================================================

def blend(m,randtimes, dt, lineindx, shotindx,nshots, nlines,ntraces):
    '''Blend the input data.'''

    n3, n2, n1 = m.shape

    ## extend lendata to allow for selfsimultaneous source separation
    lendata = np.ceil(np.max(randtimes) + 3 * n1)

    sdata = gammaf(m,randtimes,lendata, n1, lineindx,shotindx,ntraces)

    combed = gammat(sdata, randtimes, n1, n1,
                    n2, n3,lineindx,shotindx,ntraces)

# --------------------------------------------------------------

#   QC code
    if ( 1 == 2):
            #  display blended data
        fig = plt.figure()
        plt.plot(sdata[0:1000])
        ttt = 'Blended Data '
        plt.title(ttt)
          #  display input Data
        fig = plt.figure()
        mmm = np.reshape(m, (n2*n3, n1))
        plt.imshow(np.transpose(mmm), aspect='auto', cmap='gray')
        ttt = 'Input Data'
        plt.title(ttt)
        plt.colorbar()
        plt.show()
# --------------------------------------------------------------

    return sdata,combed  



#=================================================================
