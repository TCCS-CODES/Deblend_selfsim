%clc
clear;
close all;
pause(0.001)



fid1=fopen('sitfile.txt','w');


%  shoot about every 2 seconds
 shotskip = 3.0 / 0.004;
 tau = 0.250 / 0.004;

samptime = 0;
for iline=1:6
samptime = samptime + round(rand * 5 * shotskip);
    for ishot=1:20
        fprintf(fid1,' %d   %d   %d \n',samptime, iline, ishot);
        samptime = samptime + shotskip + floor(tau * rand);
    end
end



