#!/usr/bin/env python3
'Deblend data'

# Copyright (C) 2020 Raymond Abma, The University of Texas at Austin
##
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
##
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
##
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

try:
    import numpy as np
    import rsf.api as rsf
except Exception as e:
    print('ERROR : need numpy')
    sys.exit(1)

from deblend import deblend
from deblend import blend
from timework import timewrk
import sys
import matplotlib.pyplot as plt
import time
import datetime

# Input and output file 
par = rsf.Par()
inp = rsf.Input()
out = rsf.Output()


mode = par.string('mode','deblend')
sys.stderr.write('processing mode='+str(mode)+' \n')
if (mode != 'deblend'):
    if (mode != 'blend'):
        sys.stderr.write('mode process must be deblend or blend')
        sys.stderr.write(" +++ exiting +++ \n")
        sys.exit(1)

if (mode == 'blend'):
    outtype = par.string('outtype','continuous')
    sys.stderr.write('blending output type ='+str(outtype)+' \n')
    if (outtype != 'continuous'):
        if (outtype != 'combed'):
            sys.stderr.write('blended output type must be continuous or combed')
            sys.stderr.write(" +++ exiting +++ \n")
            sys.exit(1)


sitfile = par.string('sitfile','sitfile.txt')
sys.stderr.write('input source times='+str(sitfile)+' \n')


# Read command line parameters

niter = par.int('niter',300)
w1 = par.int('w1',100)
w2 = par.int('w2',15)
w3 = par.int('w3',15)
t0 = par.int('t0',0)

# output trace length for deblending
out_n1 = par.int('out_n1',1000)
sys.stderr.write('out_n1='+str(out_n1)+' \n')

dx = par.int('dx',30)
dy = par.int('dy',0)

padded = par.int('padded',0)

if ( padded != 0):
    sys.stderr.write(' outputing padded data \n')  

# Read input data


inp_n1 = inp.int('n1')
inp_n2 = inp.int('n2')
if (inp_n2 == None):
    inp_n2 = 1
inp_n3 = inp.int('n3')
if (inp_n3 == None):
    inp_n3 = 1

dt = inp.float('d1')

# if we don't specify t0, get it from the header file
if (t0 == 0):
    t0 = inp.int('t0')
sys.stderr.write('t0='+str(t0)+'\n')  

if ( mode == 'deblend'):

    inp_n2 =1
    inp_n3 =1
    sdata_in = np.zeros((inp_n1), dtype=np.float32)
    sdata = np.zeros((inp_n1+out_n1)) # extra space for self-simultaneous separation
    inp.read(sdata_in)
    for i1 in range(inp_n1):
        sdata[i1] = float(sdata_in[i1])

else: 

#   for blending, use the input trace length to process
    out_n1 = inp_n1

    sdata_in = np.zeros((inp_n3,inp_n2,inp_n1), dtype=np.float32)
    sdata = np.zeros((inp_n3,inp_n2,inp_n1))

    inp.read(sdata_in)
    for i3 in range(inp_n3):
        for i2 in range(inp_n2):
            for i1 in range(inp_n1):
                sdata[i3,i2,i1] = float(sdata_in[i3,i2,i1])

#  if we are combing, make the output trace length the same as the input
    if (out_n1 == None):
        out_n1 =  inp_n1


#  read and process the source times

leninputtrace = np.shape(sdata)[0]


shottimes,nlines,nshots,lineindx,shotindx,maxtime,mintime,ntraces=timewrk(sitfile,mode,out,leninputtrace,out_n1,t0)

if (mode == 'blend'):  # blend ------------

    sdata,combed = blend(sdata,shottimes, dt, lineindx, shotindx,nshots, nlines,ntraces)

    if (outtype == 'combed'):  # output combed data

        out_n1 = np.shape(combed)[2]
        out_n2 = np.shape(combed)[1]
        out_n3 = np.shape(combed)[0]
    
        combed_single=np.zeros((out_n3,out_n2,out_n1),dtype=np.float32)
    
        for i3 in range(out_n3):
            for i2 in range(out_n2):
                for i1 in range(out_n1):
                    combed_single[i3][i2][i1] = np.float32(combed[i3][i2][i1])
    
        out.put('n1',out_n1)
        out.put('n2',out_n2)
        out.put('n3',out_n3)
        out.write(combed_single)

    else:   # output continuous blended data

        lendata = (out_n1*4)+maxtime-mintime+1 # 4 to allow self-simultaneous sources
        out_n2 = 1
        out_n3 = 1
    
        m_single=np.zeros((lendata),dtype=np.float32)
    
        lensdata = np.shape(sdata)[0]
        for i1 in range(lensdata):
            m_single[i1] = np.float32(sdata[i1])
    
        out.put('n1',lendata)
        out.put('n2',1)
        out.put('n3',1)
        out.write(m_single)


else:  # deblend -------------

    lendata = out_n1+maxtime-mintime

    m = deblend(sdata, out_n1, dt, shottimes, niter,lendata,w1,w2,w3,nshots,nlines,lineindx,shotindx,ntraces)

    out.put('w1',w1)
    out.put('w2',w2)
    out.put('w3',w3)

    if ( padded != 0):   # output padded data

        out_n2 = np.shape(m)[1]
        out_n3 = np.shape(m)[0]

        m_single=np.zeros((out_n3,out_n2,out_n1),dtype=np.float32)

        for i3 in range(out_n3):
            for i2 in range(out_n2):
                for i1 in range(out_n1):
                    m_single[i3][i2][i1] = np.float32(m[i3][i2][i1])

        out.put('n1',out_n1)
        out.put('n2',out_n2)
        out.put('n3',out_n3)

        out.write(m_single)

    else:   # output regular data
        out_n2 = nshots
        out_n3 = nlines

        m_single=np.zeros((out_n3,out_n2,out_n1),dtype=np.float32)

        icnt = 0
        for i3 in range(nlines):
            for i2 in range(nshots):
                ilne = lineindx[icnt] 
                isht = shotindx[icnt] 
                icnt = icnt + 1
                for i1 in range(out_n1):
                    m_single[i3][i2][i1] = np.float32(m[i3][i2][i1])

        out.put('n1',out_n1)
        out.put('n2',nshots)
        out.put('n3',nlines)

        out.write(m_single)

    
out.close()
