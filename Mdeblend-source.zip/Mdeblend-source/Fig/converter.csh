#! /bin/csh 

foreach III (*.vpl)

echo  'file=' ${III}


set X = `echo  ${III}  | awk -F'.' '{print $1}'`
set XXX = "${X}.pdf"
echo $XXX

tiffpen  ${III} > junkk.tiff  bgcolor=white
magick junkk.tiff ${XXX}
rm -f junkk.tiff


end
